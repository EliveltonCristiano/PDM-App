<template src="./schema-gen.html">
</template>

<style lang="scss" src="./schema-gen.scss">
</style>

<script src="./schema-gen.js">
</script>
