import playground from "./playground/index.vue";
import schemaGen from "./schema-gen/index.vue";
// Don't touch me - import

module.exports = {
  playground,
  schemaGen
  // Don't touch me - export
};
