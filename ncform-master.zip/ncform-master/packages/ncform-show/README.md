## ncform show

The stage of the ncform show, currently provides Playground and Schema Generator

# How to dev

Step 1: prepare the dependency nc libraries
```sh
cd ../../ && npm run build
```

Step 2: start development
```sh
npm run dev
```
