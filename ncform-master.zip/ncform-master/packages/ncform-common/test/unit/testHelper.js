require('babel-core/register')({
  ignore: /node_modules\/(?!lodash-es)/
});
