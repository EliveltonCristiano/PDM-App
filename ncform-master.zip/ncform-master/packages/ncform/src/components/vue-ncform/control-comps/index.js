import input from "./input.vue";
// Don't touch me - import

module.exports = {
  input
  // Don't touch me - exports
};
