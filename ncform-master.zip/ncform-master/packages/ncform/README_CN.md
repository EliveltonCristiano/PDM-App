# ncform

ncform，一种令人愉悦的表单开发方式，仅需配置即可生成表单UI及其交互行为。

更详细信息请访问官网：[https://github.com/ncform/ncform](https://github.com/ncform/ncform)

# How to dev

Step 1: prepare the dependency nc libraries
```sh
cd ../../ && npm run build
```

Step 2: start development
```sh
npm run dev
```

[可选]配合以下可使用依赖的`ncform-common`的最新代码
```
cd ../ncform-common
npm run watch-build
```


